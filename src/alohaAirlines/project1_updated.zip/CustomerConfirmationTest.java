package alohaAirlines;

import static org.junit.Assert.*;

import org.junit.Test;

public class CustomerConfirmationTest {

	@Test
	public void test() {
		assert
	}

}
